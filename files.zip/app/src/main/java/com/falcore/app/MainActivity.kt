package com.falcore.app

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import java.net.URL
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var jokeText: TextView
    private lateinit var btnJoke: Button
    private val apiUrl = "https://official-joke-api.appspot.com/random_joke"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        jokeText = findViewById(R.id.jokeText)
        btnJoke = findViewById(R.id.btnJoke)
        btnJoke.setOnClickListener { getJoke() }
    }

    private fun getJoke() {
        jokeText.text = "Loading..."
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val json = URL(apiUrl).readText()
                val obj = JSONObject(json)
                val setup = obj.getString("setup")
                val punchline = obj.getString("punchline")
                withContext(Dispatchers.Main) {
                    jokeText.text = "$setup\n\n$punchline"
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    jokeText.text = "Failed to get joke: ${e.message}"
                }
            }
        }
    }
}